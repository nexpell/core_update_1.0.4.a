<?php
declare(strict_types=1);

/**
 * JoinUs → User-Erstellung
 * BASISDATEI (TODO-STUFE)
 */



/**
 * Erstellt später einen User aus einer JoinUs-Bewerbung.
 * Aktuell: Gibt nur einen sichtbaren TODO-Hinweis zurück.
 *
 * @param int $applicationId
 * @return array
 */
function createUserFromJoinUs(int $applicationId): array
{
    global $_database, $languageService;

    /* ===============================
       1) Bewerbung laden
    =============================== */
    $stmt = $_database->prepare("
        SELECT id, email, name, type, status
        FROM plugins_joinus_applications
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->bind_param("i", $applicationId);
    $stmt->execute();
    $res = $stmt->get_result();
    $application = $res->fetch_assoc();
    $stmt->close();

    if (!$application) {
        return [
            'success' => false,
            'error'   => true,
            'message' => $languageService->get('todo_not_found')
        ];
    }

    /* ===============================
       2) TODO-HINWEIS (ABSICHTLICH)
    =============================== */
    return [
        'success' => false,
        'todo'    => true,
        'title'   => $languageService->get('todo_title'),
        'message' => $languageService->get('todo_message'),
        'tasks'   => [
            $languageService->get('todo_task_email_exists'),
            $languageService->get('todo_task_create_user'),
            $languageService->get('todo_task_password'),
            $languageService->get('todo_task_assign_role'),
            $languageService->get('todo_task_link_application'),
            $languageService->get('todo_task_send_mail')
        ],
        'application' => [
            'id'     => (int)$application['id'],
            'email'  => $application['email'],
            'name'   => $application['name'],
            'type'   => $application['type'],
            'status' => $application['status']
        ]
    ];
}
