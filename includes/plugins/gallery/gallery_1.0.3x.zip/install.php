<?php

global $_database;

safe_query("CREATE TABLE IF NOT EXISTS plugins_gallery_categories (
  id int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  name varchar(100) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

safe_query("CREATE TABLE IF NOT EXISTS plugins_gallery (
  id int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  filename varchar(255) NOT NULL,
  title varchar(255) NOT NULL DEFAULT '',
  caption text NULL,
  alt_text varchar(255) NOT NULL DEFAULT '',
  tags varchar(255) NOT NULL DEFAULT '',
  photographer varchar(255) NOT NULL DEFAULT '',
  width int(10) UNSIGNED NOT NULL DEFAULT 0,
  height int(10) UNSIGNED NOT NULL DEFAULT 0,
  class enum('wide','tall','big','') DEFAULT '',
  upload_date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  position int(10) UNSIGNED NOT NULL DEFAULT 0,
  category_id int(10) UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY category_id (category_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

safe_query("ALTER TABLE plugins_gallery ADD COLUMN IF NOT EXISTS title varchar(255) NOT NULL DEFAULT '' AFTER filename");
safe_query("ALTER TABLE plugins_gallery ADD COLUMN IF NOT EXISTS caption text NULL AFTER title");
safe_query("ALTER TABLE plugins_gallery ADD COLUMN IF NOT EXISTS alt_text varchar(255) NOT NULL DEFAULT '' AFTER caption");
safe_query("ALTER TABLE plugins_gallery ADD COLUMN IF NOT EXISTS tags varchar(255) NOT NULL DEFAULT '' AFTER alt_text");
safe_query("ALTER TABLE plugins_gallery ADD COLUMN IF NOT EXISTS photographer varchar(255) NOT NULL DEFAULT '' AFTER tags");
safe_query("ALTER TABLE plugins_gallery ADD COLUMN IF NOT EXISTS width int(10) UNSIGNED NOT NULL DEFAULT 0 AFTER photographer");
safe_query("ALTER TABLE plugins_gallery ADD COLUMN IF NOT EXISTS height int(10) UNSIGNED NOT NULL DEFAULT 0 AFTER width");

safe_query("INSERT IGNORE INTO plugins_gallery (id, filename, title, alt_text, tags, photographer, class, upload_date, position, category_id) VALUES
(1, 'img_68839134a01b4.jpg', 'Gallery Image 1', 'Gallery Image 1', 'sample,gallery', 'nexpell', '', CURRENT_TIMESTAMP, 1, 1),
(2, 'img_688391421701b.jpg', 'Gallery Image 2', 'Gallery Image 2', 'sample,gallery', 'nexpell', 'wide', CURRENT_TIMESTAMP, 2, 1),
(3, 'img_6883914ca02e4.jpg', 'Gallery Image 3', 'Gallery Image 3', 'sample,gallery', 'nexpell', 'tall', CURRENT_TIMESTAMP, 3, 1),
(4, 'img_688391578247d.jpg', 'Gallery Image 4', 'Gallery Image 4', 'sample,gallery', 'nexpell', 'wide', CURRENT_TIMESTAMP, 4, 1),
(5, 'img_68839167eadb7.jpg', 'Gallery Image 5', 'Gallery Image 5', 'sample,gallery', 'nexpell', '', CURRENT_TIMESTAMP, 5, 1),
(6, 'img_688391793db05.jpg', 'Gallery Image 6', 'Gallery Image 6', 'sample,gallery', 'nexpell', 'tall', CURRENT_TIMESTAMP, 6, 1),
(7, 'img_6883918321c6a.jpg', 'Gallery Image 7', 'Gallery Image 7', 'sample,gallery', 'nexpell', '', CURRENT_TIMESTAMP, 7, 1),
(8, 'img_6883918f85626.jpg', 'Gallery Image 8', 'Gallery Image 8', 'sample,gallery', 'nexpell', 'big', CURRENT_TIMESTAMP, 8, 1),
(9, 'img_6883919ad6c13.jpg', 'Gallery Image 9', 'Gallery Image 9', 'sample,gallery', 'nexpell', '', CURRENT_TIMESTAMP, 9, 1),
(10, 'img_688391a5ecfa1.jpg', 'Gallery Image 10', 'Gallery Image 10', 'sample,gallery', 'nexpell', '', CURRENT_TIMESTAMP, 10, 1),
(11, 'img_688391b3c986c.jpg', 'Gallery Image 11', 'Gallery Image 11', 'sample,gallery', 'nexpell', 'wide', CURRENT_TIMESTAMP, 11, 1),
(12, 'img_688391be98734.jpg', 'Gallery Image 12', 'Gallery Image 12', 'sample,gallery', 'nexpell', '', CURRENT_TIMESTAMP, 12, 1)");

## SYSTEM #####################################################################################################################################

safe_query("
    INSERT IGNORE INTO settings_plugins
        (pluginID, modulname, admin_file, activate, author, website, index_link, hiddenfiles, version, path, status_display, plugin_display, widget_display, delete_display, sidebar)
    VALUES
        ('', 'gallery', 'admin_gallery', 1, 'T-Seven', 'https://www.nexpell.de', 'gallery', '', '1.0.3.3', 'includes/plugins/gallery/', 1, 1, 0, 1, 'deactivated')
");

safe_query("
    INSERT IGNORE INTO settings_plugins_lang
        (content_key, language, content, modulname, updated_at)
    VALUES
        ('plugin_name_gallery', 'de', 'Gallery', 'gallery', NOW()),
        ('plugin_name_gallery', 'en', 'Gallery', 'gallery', NOW()),
        ('plugin_name_gallery', 'it', 'Gallery', 'gallery', NOW()),
        ('plugin_info_gallery', 'de', 'Mit diesem Plugin koennt ihr eine Gallery auf der Webseite anzeigen lassen.', 'gallery', NOW()),
        ('plugin_info_gallery', 'en', 'With this plugin you can display a gallery on the website.', 'gallery', NOW()),
        ('plugin_info_gallery', 'it', 'Con questo plugin puoi visualizzare una galleria sul sito web.', 'gallery', NOW())
    ON DUPLICATE KEY UPDATE
        content = VALUES(content),
        modulname = VALUES(modulname),
        updated_at = VALUES(updated_at)
");

safe_query("
    INSERT IGNORE INTO settings_plugins_installed
        (name, modulname, description, version, author, url, folder, installed_date)
    VALUES
        ('Gallery', 'gallery', 'With this plugin you can display a gallery on the website.', '1.0.3.3', 'T-Seven', 'https://www.nexpell.de', 'gallery', NOW())
    ON DUPLICATE KEY UPDATE
        name = VALUES(name),
        description = VALUES(description),
        version = VALUES(version),
        author = VALUES(author),
        url = VALUES(url),
        folder = VALUES(folder),
        installed_date = NOW()
");

## NAVIGATION #####################################################################################################################################

$linkID = 0;
$linkRes = safe_query("
    SELECT linkID FROM navigation_dashboard_links
    WHERE modulname = 'gallery' AND url = 'admincenter.php?site=admin_gallery'
    ORDER BY linkID ASC LIMIT 1
");
if ($linkRes && ($linkRow = mysqli_fetch_assoc($linkRes))) {
    $linkID = (int) ($linkRow['linkID'] ?? 0);
} else {
    safe_query("
        INSERT IGNORE INTO navigation_dashboard_links
            (catID, modulname, url, sort)
        VALUES
            (9, 'gallery', 'admincenter.php?site=admin_gallery', 1)
    ");
    $linkID = (int) mysqli_insert_id($_database);
}

if ($linkID > 0) {
    safe_query("
        INSERT IGNORE INTO navigation_dashboard_lang
            (content_key, language, content, modulname, updated_at)
        VALUES
            ('nav_link_{$linkID}', 'de', 'Gallery', 'gallery', NOW()),
            ('nav_link_{$linkID}', 'en', 'Gallery', 'gallery', NOW()),
            ('nav_link_{$linkID}', 'it', 'Gallery', 'gallery', NOW())
        ON DUPLICATE KEY UPDATE
            content = VALUES(content),
            modulname = VALUES(modulname),
            updated_at = VALUES(updated_at)
    ");
}

$snavID = 0;
$snavRes = safe_query("
    SELECT snavID FROM navigation_website_sub
    WHERE modulname = 'gallery' AND url = 'index.php?site=gallery'
    ORDER BY snavID ASC LIMIT 1
");
if ($snavRes && ($snavRow = mysqli_fetch_assoc($snavRes))) {
    $snavID = (int) ($snavRow['snavID'] ?? 0);
} else {
    safe_query("
        INSERT IGNORE INTO navigation_website_sub
            (mnavID, modulname, url, sort, indropdown, last_modified)
        VALUES
            (4, 'gallery', 'index.php?site=gallery', 1, 1, NOW())
    ");
    $snavID = (int) mysqli_insert_id($_database);
}

if ($snavID > 0) {
    safe_query("
        INSERT IGNORE INTO navigation_website_lang
            (content_key, language, content, modulname, updated_at)
        VALUES
            ('nav_sub_{$snavID}', 'de', 'Gallery', 'gallery', NOW()),
            ('nav_sub_{$snavID}', 'en', 'Gallery', 'gallery', NOW()),
            ('nav_sub_{$snavID}', 'it', 'Gallery', 'gallery', NOW())
        ON DUPLICATE KEY UPDATE
            content = VALUES(content),
            modulname = VALUES(modulname),
            updated_at = VALUES(updated_at)
    ");
}

#######################################################################################################################################
safe_query("
  INSERT IGNORE INTO user_role_admin_navi_rights (id, roleID, type, modulname)
  VALUES ('', 1, 'link', 'gallery')
");
?>
