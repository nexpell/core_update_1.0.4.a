<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

use nexpell\LanguageService;
use nexpell\SeoUrlHandler;

global $languageService;

$config = mysqli_fetch_array(safe_query("SELECT selected_style FROM settings_headstyle_config WHERE id=1"));
$class = htmlspecialchars($config['selected_style']);

// Header-Daten
$data_array = [
    'class'    => $class,
    'title'    => $languageService->get('rules_title'),
    'subtitle' => 'Rules'
];
echo $tpl->loadTemplate("rules", "head", $data_array, "plugin");

// Anzahl aller aktiven Regeln zählen
$alle = safe_query("SELECT id FROM plugins_rules WHERE is_active = 1");
$gesamt = mysqli_num_rows($alle);

// Maximale Anzahl pro Seite (aus Einstellungen oder Standard 10)
$settings = safe_query("SELECT * FROM plugins_rules_settings"); // Optional, anpassen wenn genutzt
$dn = mysqli_fetch_array($settings);
$max = !empty($dn['clan_rules']) ? (int)$dn['clan_rules'] : 10;

$pages = ceil($gesamt / $max);
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max(1, min($page, $pages));
$start = ($page - 1) * $max;

// Aktive Regeln holen
$currentLang = $_SESSION['language'] ?? 'de';

/* =========================================
   1️⃣ Alle Rule-IDs ermitteln
========================================= */
$resRules = safe_query("
    SELECT 
        SUBSTRING_INDEX(SUBSTRING_INDEX(content_key, '_', 2), '_', -1) AS rule_id,
        MAX(sort_order) AS sort_order,
        MAX(updated_at) AS updated_at,
        MAX(userID) AS userID
    FROM plugins_rules
    WHERE content_key LIKE 'rule_%_title'
      AND is_active = 1
    GROUP BY rule_id
    ORDER BY sort_order ASC
    LIMIT $start, $max
");

if (mysqli_num_rows($resRules) > 0) {

    while ($rule = mysqli_fetch_assoc($resRules)) {

        $ruleID = (int)$rule['rule_id'];

        /* =========================================
           2️⃣ Titel holen
        ========================================= */
        $resTitle = safe_query("
            SELECT content
            FROM plugins_rules
            WHERE content_key = 'rule_{$ruleID}_title'
              AND language = '{$currentLang}'
            LIMIT 1
        ");

        $rowTitle = mysqli_fetch_assoc($resTitle);
        $title = $rowTitle['content'] ?? '';

        /* =========================================
           3️⃣ Text holen
        ========================================= */
        $resText = safe_query("
            SELECT content
            FROM plugins_rules
            WHERE content_key = 'rule_{$ruleID}_text'
              AND language = '{$currentLang}'
            LIMIT 1
        ");

        $rowText = mysqli_fetch_assoc($resText);
        $text = $rowText['content'] ?? '';

        /* =========================================
           4️⃣ Poster
        ========================================= */
        $poster = '<a href="' .
            SeoUrlHandler::convertToSeoUrl(
                'index.php?site=profile&id=' . $rule['userID']
            ) .
            '"><strong>' . getusername($rule['userID']) . '</strong></a>';

        $date = !empty($rule['updated_at'])
            ? date("d.m.Y", strtotime($rule['updated_at']))
            : '';

        $data_array = [
            'title'  => htmlspecialchars($title, ENT_QUOTES, 'UTF-8'),
            'text'   => htmlspecialchars($text, ENT_QUOTES, 'UTF-8'),
            'date'   => $date,
            'poster' => $poster,
            'info'   => $languageService->get('info'),
            'stand'  => $languageService->get('stand')
        ];

        echo $tpl->loadTemplate("rules", "main", $data_array, "plugin");
    }

    echo $tpl->renderPagination("index.php?site=rules", $page, $pages);

} else {
    echo '<div class="alert alert-info">' .
        $languageService->get('no_rules_found') .
        '</div>';
}
?>

