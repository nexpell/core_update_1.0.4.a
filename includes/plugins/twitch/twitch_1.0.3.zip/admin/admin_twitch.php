<?php

// Session absichern
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

use nexpell\LanguageService;
use nexpell\AccessControl;

// Admin-Zugriff prüfen
AccessControl::checkAdminAccess('twitch');

global $_database, $languageService;

if (isset($languageService) && method_exists($languageService, 'readModule')) {
    $languageService->readModule('twitch');
}

if (!function_exists('twitch_ensure_settings_schema')) {
    function twitch_ensure_settings_schema(mysqli $database): void
    {
        static $ensured = false;

        if ($ensured) {
            return;
        }

        $requiredColumns = [
            'client_id' => "ALTER TABLE plugins_twitch_settings ADD client_id varchar(255) NOT NULL DEFAULT '' AFTER extra_channels",
            'client_secret' => "ALTER TABLE plugins_twitch_settings ADD client_secret varchar(255) NOT NULL DEFAULT '' AFTER client_id",
        ];

        foreach ($requiredColumns as $column => $sql) {
            $exists = $database->query("SHOW COLUMNS FROM plugins_twitch_settings LIKE '" . $database->real_escape_string($column) . "'");
            if ($exists instanceof mysqli_result && $exists->num_rows === 0) {
                $database->query($sql);
            }
        }

        $ensured = true;
    }
}

twitch_ensure_settings_schema($_database);

// POST speichern
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $main = $_database->real_escape_string($_POST['main_channel'] ?? '');
    $extra = $_database->real_escape_string($_POST['extra_channels'] ?? '');
    $clientId = $_database->real_escape_string($_POST['client_id'] ?? '');
    $clientSecret = $_database->real_escape_string($_POST['client_secret'] ?? '');

    $sql = "UPDATE plugins_twitch_settings SET main_channel='$main', extra_channels='$extra', client_id='$clientId', client_secret='$clientSecret' WHERE id = 1";
    if ($_database->query($sql)) {
        nx_alert('success', 'alert_saved', false);
    } else {
        nx_alert('danger', 'alert_db_error', false);
    }
}

// Aktuelle Werte holen
$result = $_database->query("SELECT main_channel, extra_channels, client_id, client_secret FROM plugins_twitch_settings WHERE id = 1");
if ($result && $row = $result->fetch_assoc()) {
  $main_channel = $row['main_channel'];
  $extra_channels = $row['extra_channels'];
  $client_id = $row['client_id'];
  $client_secret = $row['client_secret'];
} else {
  $main_channel = "";
  $extra_channels = "";
  $client_id = "";
  $client_secret = "";
}
?>

<div class="card shadow-sm mt-4">
    <div class="card-header">
        <div class="card-title">
            <i class="bi bi-twitch"></i> <span><?= $languageService->get('title_twitch') ?></span>
            <small class="text-muted"><?= $languageService->get('overview') ?></small>
        </div>
    </div>

    <div class="card-body">
        <form method="POST" class="needs-validation" novalidate>
            <div class="mb-3">
                <label for="main_channel" class="form-label"><?= $languageService->get('label_mainchannel') ?></label>
                <input type="text" class="form-control" id="main_channel" name="main_channel" value="<?= htmlspecialchars($main_channel) ?>" required>
            </div>

            <div class="mb-3">
                <label for="extra_channels" class="form-label"><?= $languageService->get('label_subchannels') ?></label>
                <textarea class="form-control" id="extra_channels" name="extra_channels" rows="3"><?= htmlspecialchars($extra_channels) ?></textarea>
            </div>

            <div class="mb-3">
                <label for="client_id" class="form-label"><?= $languageService->get('label_client_id') ?></label>
                <input type="text" class="form-control" id="client_id" name="client_id" value="<?= htmlspecialchars($client_id) ?>">
                <div class="form-text"><?= $languageService->get('help_client_id') ?></div>
            </div>

            <div class="mb-3">
                <label for="client_secret" class="form-label"><?= $languageService->get('label_client_secret') ?></label>
                <input type="password" class="form-control" id="client_secret" name="client_secret" value="<?= htmlspecialchars($client_secret) ?>" autocomplete="new-password">
                <div class="form-text"><?= $languageService->get('help_client_secret') ?></div>
            </div>

            <button type="submit" class="btn btn-primary">
                <?= $languageService->get('save') ?>
            </button>
        </form>
    </div>
</div>
