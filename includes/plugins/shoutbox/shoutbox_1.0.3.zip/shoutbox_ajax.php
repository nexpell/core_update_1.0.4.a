<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* =========================================================
   Fehler nur loggen – kein Output!
========================================================= */
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/shoutbox_error.log');

/* =========================================================
   JSON Helper
========================================================= */
function json_response(array $data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/* =========================================================
   Config laden
========================================================= */
$configPath = __DIR__ . '/../../../system/config.inc.php';
if (!file_exists($configPath)) {
    json_response(['status' => 'error', 'message' => 'Config nicht gefunden'], 500);
}
require_once $configPath;

/* =========================================================
   DB Verbindung
========================================================= */
$_database = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($_database->connect_error) {
    json_response(['status' => 'error', 'message' => 'DB Verbindung fehlgeschlagen'], 500);
}

/* =========================================================
   Username
========================================================= */
$usernameSession = trim($_SESSION['username'] ?? '');

/* =========================================================
   POST → Nachricht speichern
========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = $usernameSession !== ''
        ? $usernameSession
        : trim($_POST['username'] ?? '');

    $message  = trim($_POST['message'] ?? '');

    if ($username === '' || $message === '') {
        json_response(['status' => 'error', 'message' => 'Name und Nachricht sind erforderlich'], 400);
    }

    if (mb_strlen($message) > 500) {
        json_response(['status' => 'error', 'message' => 'Nachricht max. 500 Zeichen'], 400);
    }

    $stmt = $_database->prepare("
        INSERT INTO plugins_shoutbox_messages
        (created_at, username, message)
        VALUES (NOW(), ?, ?)
    ");

    if (!$stmt) {
        json_response(['status' => 'error', 'message' => $_database->error], 500);
    }

    $stmt->bind_param('ss', $username, $message);

    if (!$stmt->execute()) {
        json_response(['status' => 'error', 'message' => $stmt->error], 500);
    }

    $stmt->close();

    json_response(['status' => 'success']);
}

/* =========================================================
   GET → Nachrichten laden
========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    $result = $_database->query("
        SELECT
            id,
            created_at AS timestamp,
            username,
            message
        FROM plugins_shoutbox_messages
        ORDER BY created_at DESC
        LIMIT 100
    ");

    if (!$result) {
        json_response(['status' => 'error', 'message' => $_database->error], 500);
    }

    $messages = [];

    while ($row = $result->fetch_assoc()) {
        $messages[] = [
            'id'        => (int)$row['id'],
            'timestamp' => $row['timestamp'], // DATETIME
            'username'  => $row['username'],
            'message'   => $row['message'],
        ];
    }

    $result->free();

    json_response(['status' => 'success', 'messages' => $messages]);
}

/* =========================================================
   Fallback
========================================================= */
json_response(['status' => 'error', 'message' => 'Method not allowed'], 405);
